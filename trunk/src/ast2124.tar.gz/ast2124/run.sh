#!/bin/bash
java -cp bin/ FileParser "$1" "$2"
